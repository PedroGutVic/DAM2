package com.iesvdc.dam.demo2.modelos;

public enum Rol {
    ADMIN,
    CLIENTE,
    OPERARIO    
}
