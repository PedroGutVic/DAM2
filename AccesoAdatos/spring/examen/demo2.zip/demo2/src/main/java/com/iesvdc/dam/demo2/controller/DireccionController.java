package com.iesvdc.dam.demo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.iesvdc.dam.demo2.repositorios.RepoDireccion;



@Controller
@RequestMapping("/admin/user/{id}/direccion")
public class DireccionController {
    
    @Autowired
    RepoDireccion repoDireccion;

    @GetMapping({"","/"})
    public String findAll(Model modelo) {
        modelo.addAttribute("titulo", "Listado de Provincias");
        modelo.addAttribute("listaDirecciones", repoDireccion.findAll());
        return "/Direccion/list";
    }
}
