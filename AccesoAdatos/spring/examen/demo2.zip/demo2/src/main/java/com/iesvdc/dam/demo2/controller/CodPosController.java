package com.iesvdc.dam.demo2.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.iesvdc.dam.demo2.modelos.CodPos;
import com.iesvdc.dam.demo2.repositorios.RepoCodPos;

import io.micrometer.common.lang.NonNull;

@Controller
@RequestMapping("/admin/CodPos")
public class CodPosController {
    @Autowired
    RepoCodPos repocodpos;

    @GetMapping({ "", "/" })
    public String findAll(Model modelo) {
        modelo.addAttribute("listaProvincias", repocodpos.findAll());
        return "/CodPos/List";
    }

    @GetMapping("/add")
    public String add(Model modelo) {
        modelo.addAttribute("accion", "añadir");
        modelo.addAttribute("CodPos", new CodPos());
        return "CodPos/create";
    }

    @PostMapping("/save")
    public String save(
            @ModelAttribute("CodPos") CodPos CodPos) {
        repocodpos.save(CodPos);
        return "redirect: /admin/CodPos";
    }

    @GetMapping("/edit/{id}")
    public String editForm(
            Model modelo,
            @PathVariable(name = "cp") @NonNull Integer cp) {

        Optional<CodPos> oCodPos = repocodpos.findByCp(cp);
        if (oCodPos.isPresent()) {
            modelo.addAttribute("accion", "editar");
            modelo.addAttribute("CodPos", oCodPos.get());
            return "CodPos/create";
        } else {
            modelo.addAttribute("titulo", "Gestión de CodPoss");
            modelo.addAttribute("mensaje", "Esa CodPos no existe");
            return "error";
        }
    }

    @PostMapping("/edit/{id}")
    public String edit(
            @ModelAttribute("CodPos") CodPos CodPos,
            @PathVariable(name = "id") @NonNull Integer codigo) {

        repocodpos.save(CodPos);
        return "redirect:CodPos";
    }

    @GetMapping("/del/{id}")
    public String delForm(
            Model modelo,
            @PathVariable(name = "id") @NonNull Integer codigo) {

        Optional<CodPos> oCodPos = repocodpos.findByCp(codigo);
        if (oCodPos.isPresent()) {
            modelo.addAttribute("accion", "borrar");
            modelo.addAttribute("CodPos", oCodPos.get());
            return "CodPos/create";
        } else {
            modelo.addAttribute("titulo", "Gestión de CodPoss");
            modelo.addAttribute("mensaje", "Esa CodPos no existe");
            return "error";
        }
    }

    @PostMapping("/del/{id}")
    public String delByID(
            @ModelAttribute("CodPos") CodPos CodPos,
            @PathVariable(name = "id") @NonNull Integer codigo) {

        repocodpos.deleteById(codigo);
        ;
        return "redirect:/CodPos/List";
    }

}
