
package com.example.ud3.model;

public enum Rol {
    ADMIN, CLIENTE, OPERARIO
}
