
package com.example.ud3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ud3.model.Provincia;

public interface ProvinciaRepository extends JpaRepository<Provincia, String> {}
