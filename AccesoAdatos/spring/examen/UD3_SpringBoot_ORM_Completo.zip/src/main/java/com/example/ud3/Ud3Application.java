
package com.example.ud3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud3Application {
    public static void main(String[] args) {
        SpringApplication.run(Ud3Application.class, args);
    }
}
