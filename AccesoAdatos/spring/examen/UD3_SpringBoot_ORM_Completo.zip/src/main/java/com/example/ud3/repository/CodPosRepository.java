
package com.example.ud3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ud3.model.CodPos;

public interface CodPosRepository extends JpaRepository<CodPos, String> {}
