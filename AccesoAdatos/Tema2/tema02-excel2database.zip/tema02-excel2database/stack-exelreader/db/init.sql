CREATE DATABASE `agenda` COLLATE 'utf16_spanish_ci';
