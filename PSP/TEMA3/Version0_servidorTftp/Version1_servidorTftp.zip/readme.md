# Servidor TFTP

Para poder ejecutar este programa tienes que compilarlo y tener el archivo que quieres enviar,
utiliza en el primer argumento para la ip en mi caso localhost, y en el segundo para el archivo