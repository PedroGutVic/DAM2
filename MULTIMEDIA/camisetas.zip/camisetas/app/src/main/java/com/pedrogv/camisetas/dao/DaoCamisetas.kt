package com.pedrogv.camisetas.dao


import com.pedrogv.camisetas.interfaces.InterfaceDao
import com.pedrogv.camisetas.models.Camiseta
import com.pedrogv.camisetas.objects_models.Repository

class DaoCamisetas : InterfaceDao {
    companion object {
        val myDao: DaoCamisetas by lazy{ //lazy delega a un primer acceso
            DaoCamisetas() //Me creo sólo este objeto una vez.
        }
    }
    //Método que accede a la BBDD y devuelve todos los datos
    override fun getDataCamiseta(): List<Camiseta> = Repository.listTshirt
}