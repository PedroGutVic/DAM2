package com.pedrogv.camisetas.controller

import android.content.Context
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import com.pedrogv.camisetas.adapter.AdapterCamisetas
import com.pedrogv.camisetas.dao.DaoCamisetas
import com.pedrogv.camisetas.databinding.ActivityMainBinding
import com.pedrogv.camisetas.models.Camiseta



class Controller(
    private val context: Context,
    private val binding: ActivityMainBinding
) {
    private lateinit var listTshirt: MutableList<Camiseta>

    init {
        initData()
    }

    /** Inicializa la lista desde el DAO */
    private fun initData() {
        listTshirt = DaoCamisetas.myDao.getDataCamiseta().toMutableList()
    }

    /** Muestra un Toast y logea los datos */
    fun loggOut() {
        Toast.makeText(context, "He mostrado los datos en pantalla", Toast.LENGTH_LONG).show()
        listTshirt.forEach { println(it) }
    }

    /** Configura el RecyclerView con el Adapter */
    fun setAdapter() {
        binding.myRecyclerView.adapter = AdapterCamisetas(listTshirt)
    }
}
