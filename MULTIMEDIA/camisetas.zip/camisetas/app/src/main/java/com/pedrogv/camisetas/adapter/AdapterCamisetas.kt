package com.pedrogv.camisetas.adapter

import android.view.LayoutInflater
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import com.pedrogv.camisetas.R
import com.pedrogv.camisetas.models.Camiseta

class AdapterCamisetas(var listTshit : MutableList<Camiseta>) :
    RecyclerView.Adapter<ViewCamisetas>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewCamisetas {
        val layoutInflater = LayoutInflater.from(parent. context)//objeto para crear la vista.
        val layoutItemCamiseta = R.layout.card_view //accedo al xml del item a crear.
        return ViewCamisetas(layoutInflater.inflate(layoutItemCamiseta, parent, false))
    }
    override fun onBindViewHolder(holder: ViewCamisetas, position: Int) {
        holder.renderize(listTshit.get(position)) //renderizamos la view.
    }

    override fun getItemCount(): Int = listTshit.size
}


