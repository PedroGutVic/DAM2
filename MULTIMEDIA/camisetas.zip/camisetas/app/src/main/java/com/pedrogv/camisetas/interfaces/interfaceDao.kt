package com.pedrogv.camisetas.interfaces

import com.pedrogv.camisetas.models.Camiseta

interface InterfaceDao {
    fun getDataCamiseta(): List<Camiseta>
}
