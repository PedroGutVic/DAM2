package com.pedrogv.camisetas.objects_models

import com.pedrogv.camisetas.interfaces.InterfaceDao
import com.pedrogv.camisetas.models.Camiseta

object Repository : InterfaceDao {
    val listTshirt : List<Camiseta> = listOf(
        Camiseta(1, "Camiseta Básica Blanca", 15.99, "https://example.com/camiseta1.jpg"),
        Camiseta(2, "Camiseta Negra Clásica", 17.49, "https://example.com/camiseta2.jpg"),
        Camiseta(3, "Camiseta Azul Marino", 18.99, "https://example.com/camiseta3.jpg"),
        Camiseta(4, "Camiseta Roja Deportiva", 20.0, "https://example.com/camiseta4.jpg"),
        Camiseta(5, "Camiseta Verde Militar", 19.5, "https://example.com/camiseta5.jpg"),
        Camiseta(6, "Camiseta Amarilla Casual", 16.75, "https://example.com/camiseta6.jpg"),
        Camiseta(7, "Camiseta Gris Melange", 18.25, "https://example.com/camiseta7.jpg"),
        Camiseta(8, "Camiseta Estampada Retro", 21.0, "https://example.com/camiseta8.jpg"),
        Camiseta(9, "Camiseta de Manga Larga Negra", 22.5, "https://example.com/camiseta9.jpg"),
        Camiseta(10, "Camiseta Deportiva Blanca", 20.99, "https://example.com/camiseta10.jpg")
    )
    override fun getDataCamiseta(): List<Camiseta> {
        return Repository.listTshirt
    }
}