// Exportación por defecto
function mayus(texto) {
    return texto.toUpperCase();
}
  
  