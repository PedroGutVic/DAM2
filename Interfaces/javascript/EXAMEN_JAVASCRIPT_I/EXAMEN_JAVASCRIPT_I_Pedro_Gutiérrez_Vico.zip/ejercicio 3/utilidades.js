

// Exportación por defecto
export function mayus(texto) {
    return texto.toUpperCase();
}
